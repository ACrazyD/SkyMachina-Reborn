ServerEvents.tags('item', e => {
    e.add('curios:gps_slot', 'pocketgps:gps')
})
// End Of File