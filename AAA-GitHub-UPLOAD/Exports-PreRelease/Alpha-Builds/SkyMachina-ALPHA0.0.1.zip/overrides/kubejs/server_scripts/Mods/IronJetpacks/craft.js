ServerEvents.recipes(e => {
    //Remove All Current Recipes
    e.remove({ mod: 'ironjetpacks'})

    //Dirt Jetpack
    /* e.shaped(Item.of('ironjetpacks:jetpack', '{Id:"ironjetpacks:dirt"}'),[
        'dCd',
        'dBd',
        'T T'
    ],{
        d: 'minecraft:dirt',
        C: 'ironjetpacks:decrepid_capacitor',
        B: 'ironjetpacks:strap',
        T: 'ironjetpacks:rudementry_thruster'
    }) */
    //Dirt Jetpack Parts


})// End Of File    
