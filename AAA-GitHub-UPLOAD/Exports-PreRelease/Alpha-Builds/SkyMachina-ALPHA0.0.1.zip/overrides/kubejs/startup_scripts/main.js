// Visit the wiki for more info - https://kubejs.com/
console.info('Hello, Welcome to Mayhem...')

Platform.mods.kubejs.name = 'SkyTweakers'