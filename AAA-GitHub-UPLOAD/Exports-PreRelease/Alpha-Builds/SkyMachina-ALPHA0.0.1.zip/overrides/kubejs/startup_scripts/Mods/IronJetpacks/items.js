StartupEvents.registry('item', e => {
    
    e.create('ironjetpacks:primitive_coil').maxStackSize(4).displayName('Primitive Coil')
    e.create('ironjetpacks:rudementry_thruster').maxStackSize(4).displayName('Rudementry Thruster')
    e.create('ironjetpacks:decrepid_capacitor').maxStackSize(4).displayName('Decrepid Capacitor')
    e.create('ironjetpacks:destressed_cell').maxStackSize(2).displayName('Destressed Energy Cell')



})// End Of File