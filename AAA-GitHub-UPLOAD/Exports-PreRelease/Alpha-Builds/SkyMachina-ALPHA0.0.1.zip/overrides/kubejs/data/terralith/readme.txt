This folder is about to handle fiew modifications that do not suit well to islands.
Like reducing floating witch huts.